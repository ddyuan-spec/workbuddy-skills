---
name: prd-to-dingtalk
description: 将本地 HTML/Markdown PRD 发布到钉钉文档（adoc）。处理 HTML→Markdown 清洗、图片去冗余、分片创建、图片插入、回读验证，规避 dws CLI 常见踩坑。
agent_created: true
---

# PRD 推钉钉文档

## 触发条件

当用户提出以下任一请求时调用本 skill：
- "把 PRD 推到钉钉文档"
- "PRD 转钉钉文档"
- "发布到钉钉文档"
- "PRD 推钉钉"
- 任何涉及将本地 `*.html` 或 `*.md` PRD 发布为钉钉在线文档的任务

## 核心目标

把本地已审定的 PRD（通常是 HTML 单文件，也可能是 Markdown）完整、可阅、格式尽量保真地发布到钉钉文档（alidocs），并返回可分享的在线链接。同时必须清理冗余剪贴板截图，禁止把 `@image#N:Clipboard_Screenshot.png` 这类占位符写进文档。

## 前置检查

1. 确认 PRD 已通过结构/内容检查（如项目有 `check_prd.py` 或 `prd-suite` 门禁，先跑通）。
2. 确认 PRD 已推送到线上可访问地址（GitHub Pages / 公司 CDN），因为钉钉文档里的图片需要公网 URL。
3. 确认本地已安装 `dws` 且钉钉已连接：`dws profile list --format json` 能看到有效 profile。
4. 确认 PRD 中不存在 `@image#N:Clipboard_Screenshot.png`、`clipboard-*.png` 等冗余剪贴板图片引用；若有，必须删除或用真实线上图片替换。

## 工作流

### Step 1: 准备 Markdown 源

**输入**: 本地 PRD 文件（优先 `*.html`，兼容 `*.md`）。

- 若输入是 HTML：
  - 用 BeautifulSoup 清理 `<style>`、`<script>`、`<svg>`、`<noscript>` 等不会正确投影到钉钉 Markdown 的标签。
  - 用 `markdownify` 将正文转为 Markdown。
  - 保留图片 `![](url "alt")` 或内联图片块；图片 URL 必须是线上可访问地址。
  - 运行本 skill 提供的脚本：`python scripts/prd_html_to_dingtalk_md.py <input.html> [output.md]`。
- 若输入是 Markdown：
  - 直接读取并检查是否含冗余剪贴板引用；有则删除。
- **红线**：
  - 禁止把 `@image#N:Clipboard_Screenshot.png` 或类似剪贴板占位文本写入输出 Markdown。
  - 禁止把本地绝对路径图片（如 `C:\Users\...\clipboard-xxx.png`）作为图片 URL 发布。

### Step 2: 创建钉钉文档

```bash
dws doc create --name "<文档标题>" --content-file "<prmd.md>" --format json
```

- 标题建议带版本号，如 `绿韵家App数商服务模块PRD-V0.4`。
- `dws` 是 shell 脚本封装，**必须通过 Bash 调用**，不要直接用 Python `subprocess` 调 dws（Windows 会报 WinError 193）。
- 长文会自动按标题边界分片写入；命令返回 `nodeId` 与 `chunksWritten`。

### Step 3: 插入图片（如需要）

钉钉 `doc create --content-file` 对 Markdown 图片的还原度有限：
- 简单场景：Markdown 里的 `![](url)` 可直接被识别为图片块。
- 复杂场景（图注配对、多图连续）：图片块可能与相邻段落合并，导致图注丢失或顺序错乱。

**推荐做法**:
1. 先在 Markdown 中把每个图片写成独立段落，图注写成 `**图：<alt>**` 独立段落。
2. 创建文档后，用 `dws doc read --node <nodeId> --format json` 检查是否合并。
3. 若合并，按以下流程重插：
   - 读取当前 block 列表：`dws doc read --node <nodeId> --format json --content-format jsonml`。
   - 定位到空 paragraph 块（图片占位）或错误合并块。
   - 用 `dws doc media insert --node <nodeId> --file <local-img> --index <N>` 插入真实图片。
   - 用 `dws doc block delete --node <nodeId> --index <N>` 删除错误合并块。

**注意**:
- 插入本地图片前，需先把线上图片下载到本地（可用 `curl -o`）。
- TSV/CSV 等中间文件必须用 `newline='\n'` 写出，避免 Windows CRLF 导致 dws 报错。

### Step 4: 回读验证

```bash
dws doc read --node <nodeId> --format json --content-format jsonml --scope outline
```

验证项：
- 标题与一~九结构完整。
- 关键章节（如功能需求、验收标准、待确认项）未丢失。
- 没有 `@image#N:Clipboard_Screenshot.png` 或剪贴板占位文本。
- 图片顺序与 PRD 一致。

### Step 5: 交付

- 返回钉钉文档 URL：`https://alidocs.dingtalk.com/i/nodes/<nodeId>`。
- 返回线上 PRD/HTML 链接（如有）。
- 在 PRD 本地文件旁的 memory/日志中记录 nodeId 与 URL。

## 常见踩坑与规避

| 问题 | 现象 | 规避方式 |
|---|---|---|
| Python subprocess 直接调 dws | Windows 报 `WinError 193` / `不是有效的 Win32 应用程序` | 一律用 Bash 调 `dws ...` |
| Markdown 含 `<style>`/`<script>` | 钉钉文档顶部出现大段 CSS/JS 文本 | 转换前用 BeautifulSoup `decompose` 删除 |
| 剪贴板截图占位符 | 文档出现 `@image#1:Clipboard_Screenshot.png` 文本 | **删除/忽略**，不写入 Markdown；真实截图用线上 URL |
| 图片块与图注合并 | 多图只显示 24 块而非 28 块 | 用 `dws doc media insert` 按 index 重新插入，必要时 `doc block delete` 清错 |
| TSV/CSV 含 CRLF | dws 报 `CreateFile` / 文件解析失败 | Python 写文件用 `newline='\n'` |
| 分片写入超时 | create 命令部分成功 | 重试同一命令，dws 会幂等地继续写入后续分片 |
| 取旧 sha 污染 | 404 时 `gh api -q .sha` 把错误 JSON 当 sha | 用退出码判断存在性，不要 `--jq .sha` 直接取 |

## 禁止事项（强制）

- **禁止**将 `@image#N:Clipboard_Screenshot.png` 或任何剪贴板截图占位符写入钉钉文档。
- **禁止**将本地绝对路径图片作为文档图片发布。
- **禁止**使用 Python `subprocess` 直接调用 `dws`。
- **禁止**在验证失败前向用户报告“已完成”。

## 资源引用

- `scripts/prd_html_to_dingtalk_md.py`: HTML PRD → 钉钉友好 Markdown 转换器。
- `references/dws_doc_notes.md`: `dws doc` 常用命令速查与错误码说明。

## 示例用户请求

> "把 PRD 推钉钉文档"

执行顺序：
1. 定位本地 PRD HTML（如 `lvyunjia-shushang-prd.html`）。
2. 运行 `python scripts/prd_html_to_dingtalk_md.py lvyunjia-shushang-prd.html lvyunjia-shushang-prd.md`。
3. `dws doc create --name "绿韵家App数商服务模块PRD-V0.4" --content-file lvyunjia-shushang-prd.md --format json`。
4. 提取 `nodeId`，回读验证结构与关键内容。
5. 返回钉钉文档链接。
