#!/usr/bin/env python3
"""
Convert a local HTML PRD into a DingTalk-friendly Markdown file.

- Removes <style>, <script>, <svg>, <noscript> tags.
- Converts remaining HTML to Markdown via markdownify.
- Strips redundant clipboard screenshot placeholders like
  @image#1:Clipboard_Screenshot.png or local clipboard-*.png paths.
- Keeps online image URLs (e.g. GitHub Pages / CDN) intact.
"""

import argparse
import re
import sys
from pathlib import Path

try:
    from bs4 import BeautifulSoup
    from markdownify import markdownify as md
except ImportError as exc:
    print(f"Missing dependency: {exc}")
    print("Install with: pip install beautifulsoup4 markdownify lxml")
    sys.exit(1)


CLIPBOARD_PATTERNS = [
    re.compile(r"@image#\d+:[^\s)]+?Clipboard[^\s)]*?\.(png|jpg|jpeg|gif)", re.I),
    re.compile(r"clipboard-[^\s)]+?\.(png|jpg|jpeg|gif)", re.I),
    re.compile(r"file:///?[^\s)]+?\.(png|jpg|jpeg|gif)", re.I),
]

LOCAL_WINDOWS_PATH_RE = re.compile(r"[A-Za-z]:\\[^\s)]+?\.(png|jpg|jpeg|gif)", re.I)


def clean_clipboard_references(text: str) -> str:
    """Remove or neutralize redundant clipboard/local image references."""
    for pat in CLIPBOARD_PATTERNS:
        text = pat.sub("", text)
    text = LOCAL_WINDOWS_PATH_RE.sub("", text)
    # Collapse multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def html_to_dingtalk_md(html_path: str, output_path: str | None = None) -> str:
    html_file = Path(html_path)
    if not html_file.exists():
        raise FileNotFoundError(f"HTML file not found: {html_path}")

    html = html_file.read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "lxml")

    # Drop tags that pollute Markdown projection
    for tag_name in ("style", "script", "svg", "noscript"):
        for tag in soup.find_all(tag_name):
            tag.decompose()

    markdown = md(str(soup), heading_style="ATX", strip=["a"] )
    markdown = clean_clipboard_references(markdown)

    if output_path:
        out = Path(output_path)
        out.write_text(markdown, encoding="utf-8")
        print(f"Wrote {len(markdown)} chars to {out}")

    return markdown


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Convert HTML PRD to DingTalk-friendly Markdown"
    )
    parser.add_argument("input", help="Input HTML PRD file")
    parser.add_argument("output", nargs="?", help="Output Markdown file (optional)")
    args = parser.parse_args()

    try:
        html_to_dingtalk_md(args.input, args.output)
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
