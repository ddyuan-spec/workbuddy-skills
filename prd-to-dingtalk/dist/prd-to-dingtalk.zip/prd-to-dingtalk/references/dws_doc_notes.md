# dws doc 常用命令速查

## 创建文档

```bash
# 从 Markdown 文件创建（长文自动分片）
dws doc create --name "文档标题" --content-file prd.md --format json
```

返回字段：`nodeId`、`docUrl`、`chunksWritten`。

## 读取文档

```bash
# 读取 Markdown 投影（有损，不含图片 resourceId）
dws doc read --node <nodeId> --format json

# 读取大纲（轻量，验证结构）
dws doc read --node <nodeId> --format json --content-format jsonml --scope outline

# 读取完整块结构（用于定位图片占位/合并块）
dws doc read --node <nodeId> --format json --content-format jsonml
```

`--node` 支持 nodeId 或完整 alidocs URL。

## 插入/修正图片

```bash
# 插入本地图片到指定块位置
# --index 为块序号，从 0 开始；可在 read 返回的 jsonml 中数段落定位
dws doc media insert --node <nodeId> --file ./local-image.png --index <N> --format json

# 删除错误合并的块
dws doc block delete --node <nodeId> --index <N> --format json
```

## 错误处理

| 错误 | 排查 |
|---|---|
| `WinError 193` | 不要从 Python subprocess 调 dws，改用 Bash |
| `--scope/--tags requires --content-format jsonml` | outline 读取必须加 `--content-format jsonml` |
| `CreateFile` / 文件解析失败 | 中间文件含 CRLF，改 `newline='\n'` |
| 图片块合并/图注丢失 | 用 `doc media insert` 按 index 重插，并用 `doc block delete` 清错 |

## 最佳实践

1. 创建后务必 `doc read` 回读验证。
2. 图片使用线上 URL，本地图片仅在 `media insert` 时临时下载。
3. 长文档分片写入可能超时，可重试同一 `doc create` 命令继续写入。
